Chef + MDL3 共存整合包 v1.2 (WorkBuddy)
========================================

内容（4 个补丁层，按 patch_N 升序由 QD 分配连续层号）：
  patch_0  Chef Shared Loader 1.5.3 核心（资源名 core_2；boot stub 已禁用）
  patch_1  Chef Hand-off for MDL3 0.2.6 官方版，本地修改：
           核心路径 core_2、自有版本号 0.2.6-lk36.1、交接 note 带 liekong36 标识。
           已撤回上一版「每次未完成交接都重试」的加固（作者指出会让崩溃每次启动复现）。
  patch_2  官方简体中文语言包 17926
  patch_3  简体中文补充包（430 条，含 Extended Pickup Icons Range 菜单）

架构不变：MDL3 仍然是 HD2 Mod Quick Deploy 里**单独选定的 loader**，
永远最后部署、boot 在最高层；本包不含 MDL3，也不改变它的位置。
Chef 排在它下面，Hand-off 在游戏启动约 6 秒后 require Chef 核心完成交接。

兼容范围
--------
- MDL3 3.0.0-dev.36 ~ 3.0.0-dev.43 均可（两版 boot 与 Data Hub 资源 id 一致）。
- 更老的 Boot Mod Loader 0.13.4+ 在 Hand-off 0.2.5 的支持范围内。
- 整合包通过运行时探测工作，不硬编码 MDL3 版本；升级或回退 MDL3 都不用改本包。

导入 / 替换
-----------
- 首次安装：QD -> Add 导入本 zip，确认 MDL3 是选定的 loader，Deploy。
- 从旧版升级：**用 Replace，不要先删再加**，这样保留顺序、启用状态和选项：
    hd2qd replace "Chef + MDL3 共存整合包 1.0 (WorkBuddy)" "<本 zip 路径>"
  或在 QD 界面里对该条目选「替换 / Replace」并指向本 zip。
  manifest 的 Guid 与 Name 与旧版完全一致，所以能被认作同一个模组。
- 装好后关掉旧的 Chef / Hand-off / 两个语言包条目，避免重复部署。

注意
----
- 不要用原版 Chef / Hand-off 的 zip 覆盖或重装：原版核心是 core_1，
  QD 会重新把它判成 loader 并排除。
- Chef 大版本升级后需按同样办法重做 core_2 改名并迁移内置兼容逻辑。
- 完整原理、排障与回滚说明见同目录 CHANGELOG.txt 及整合包发布页。


许可与署名（v1.2）
------------------
- Chef Hand-off for MDL3 0.2.6 由 JFRedist 以 MIT 许可发布，
  Copyright (c) 2026 JFRedist；原样许可文本见 LICENSE-HANDOFF。
- 本包是**非官方修改版**，不是 JFRedist 的发布；上游：
  https://github.com/JFRedist/HD2-Chef-Handoff-for-MDL3
- 交接日志里的版本为 0.2.6-lk36.1、from 文本带 liekong36 标识，
  不会被误认成上游发布。
- 使用本包遇到问题时请反馈给 liekong36，不要打扰上游作者。
- **Chef Shared Loader 核心与其翻译属于 Th3chef**，其许可要求未经询问
  不得以任何形式再上传；许可仍在征询中。在收到回复前请勿公开分发本包。
